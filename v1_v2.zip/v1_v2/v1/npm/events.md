# events
v6.4.0新增
> 稳定性: 稳定

node中events的实现，如需使用，请用
```js
const events = require('events')
```
