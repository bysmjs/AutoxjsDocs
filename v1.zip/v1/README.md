# AutoX.js 文档

地址 : http://doc.autoxjs.com/


使用 [Docsify](https://github.com/docsifyjs/docsify/) 构建；就是将markdown转为静态网站。


## 本地开发

编写文档过程中希望，预览文档的样子，请用如下方式 启动服务

- fork 本项目
- clone 自己的仓库到本地
- 使用 vscode 打开
- 安装 `npm i docsify-cli -g`
- 运行 `docsify serve .` (后面有个 点)
- 浏览器访问 `http://localhost:3000`
