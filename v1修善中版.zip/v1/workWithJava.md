# WorkWithJava

关于调用 java [请查看这里](https://p-bakker.github.io/rhino/tutorials/scripting_java/) ，一个由 Rhino 维护者使用 GitHub Pages 部署的 Rhino 文档网站


[官方 issues 关于原 Rhino 文档地址404 的讨论](https://github.com/mozilla/rhino/issues/954#issuecomment-949763810)

