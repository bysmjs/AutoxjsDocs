![logo](images/logo.png)

# AutoX.js

> **不需要Root权限** 的 JavaScript 自动化软件

[:house: 官方社区](http://www.autoxjs.com/)
[:speech_balloon: 社区](http://zh.bmxwz.top)
[:penguin: q群](http://qm.qq.com/cgi-bin/qm/qr?_wv=1027&k=M9Jblsc4Uct5b5rCnHQKZx_OOw2nhAjt&authKey=ANG0IxelEAr4S5BHMX2pjKSKYVS3jLt0amg6A22bnxcx18F%2FCcq7eQoacBIvcEdg&noverify=0&group_code=1014521824)
[:inbox_tray: 下载](https://www.123684.com/s/EsxuVv-wqcwh)
[:book: 开始](#综述)