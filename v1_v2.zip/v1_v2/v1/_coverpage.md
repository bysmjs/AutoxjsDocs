![logo](images/logo.png)

# AutoX.js

> **不需要Root权限** 的 JavaScript 自动化软件

[:house: 社区](http://www.autoxjs.com/)
[:construction_worker: 工程化](https://github.com/kkevsekk1/webpack-autojs)
[:octocat: GitHub](https://github.com/aiselp/AutoX)
[:book: 开始](#综述)